class Test:
    def __init__(self):
        print('This is a test.')
